<?php

return [

   'THUMBNAIL_W' => '760',
   'THUMBNAIL_H' => '428',
   'ICON_W' => '75',
   'ICON_H' => '75',

];
