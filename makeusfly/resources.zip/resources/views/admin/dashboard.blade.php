@extends('layouts/admin/default')
@section('title', 'Dashboard')
@section('content')
<section class="content-header">
  <h1>
	Dashboard
	<!--small>Admin</small-->
  </h1>
  <ol class="breadcrumb">
	<li><a href="{{ url('admin') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Dashboard</li>
  </ol>
</section>
<section class="content container-fluid">


</section>
@endsection